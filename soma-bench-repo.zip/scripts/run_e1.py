from soma_bench.protocol import run_e1
if __name__ == "__main__":
    run_e1("configs/e1.yaml")
    print("E1 done → results/table1_e1_main_comparison.csv, figs/fig2_fraud_friction_curve.png")
