from soma_bench.protocol import run_e4
if __name__ == "__main__":
    run_e4("configs/e4.yaml")
    print("E4 done → results/table2_e4_rollout_slos.csv")
